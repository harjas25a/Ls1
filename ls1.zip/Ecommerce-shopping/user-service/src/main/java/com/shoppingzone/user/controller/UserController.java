package com.shoppingzone.user.controller;

import com.shoppingzone.user.model.User;
import com.shoppingzone.user.service.UserService;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/users")
public class UserController {
    @Autowired
    private UserService userService;

    @GetMapping
    public ResponseEntity<List<User>> getAllUsers(@RequestHeader("Authorization") String token) {
        userService.validateUserAccess(token.substring(7), getUsernameFromToken(token), "ADMIN");
        return ResponseEntity.ok(userService.getAllUsers());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteUser(@RequestHeader("Authorization") String token, @PathVariable Long id) {
        userService.validateUserAccess(token.substring(7), getUsernameFromToken(token), "ADMIN");
        userService.deleteUser(id);
        return ResponseEntity.ok("User deleted successfully");
    }

    @PutMapping("/{id}")
    public ResponseEntity<String> updateUser(
            @RequestHeader("Authorization") String token,
            @PathVariable Long id,
            @RequestBody User updatedUser) {
        String username = getUsernameFromToken(token);
        userService.validateUserAccess(token.substring(7), username, "USER");
        userService.updateUser(id, username, updatedUser);
        return ResponseEntity.ok("User updated successfully");
    }

    private String getUsernameFromToken(String token) {
        String jwt = token.startsWith("Bearer ") ? token.substring(7) : token;
        return userService.extractUsername(jwt);
    }
}