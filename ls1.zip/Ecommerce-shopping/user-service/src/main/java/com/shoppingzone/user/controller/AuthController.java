package com.shoppingzone.user.controller;

import com.shoppingzone.user.model.User;
import com.shoppingzone.user.service.AuthService;

import jakarta.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/auth")
public class AuthController {

    @Autowired
    private AuthService authService;

    @PostMapping("/register")
    public ResponseEntity<String> registerUser(@RequestBody @Valid  User user) {
        System.out.println(1);
        return ResponseEntity.ok(authService.registerUser(user));
    }

    @PostMapping("/login")
    public ResponseEntity<Map<String, Object>> loginUser(@RequestBody Map<String, String> credentials) {
        User user = authService.getUserByUsername(credentials.get("username"));
        if (user == null) {
            throw new RuntimeException("Invalid credentials");
        }
        String token = authService.loginUser(credentials.get("username"), credentials.get("password"));
        return ResponseEntity.ok(Map.of(
            "token", token,
            "id", user.getId(),
            "role", user.getRole(),
            "username", user.getUsername()
        ));
    }
}