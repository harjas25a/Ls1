package com.shoppingzone.user.service;

import com.shoppingzone.user.model.User;
import com.shoppingzone.user.repository.UserRepository;
import com.shoppingzone.user.security.JwtUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserService {
    @Autowired
    private UserRepository userRepository;

    @Autowired
    private JwtUtil jwtUtil;

    private final BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

    public boolean validateUserAccess(String token, String username, String requiredRole) {
        try {
            return jwtUtil.validateToken(token, username, requiredRole);
        } catch (SecurityException e) {
            throw new RuntimeException("Forbidden: Insufficient role permissions");
        }
    }

    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    public void deleteUser(Long id) {
        userRepository.deleteById(id);
    }

    public void updateUser(Long id, String username, User updatedUser) {
        User user = userRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("User not found"));
        if (!user.getUsername().equals(username)) {
            throw new RuntimeException("You can only update your own details");
        }
        user.setPassword(passwordEncoder.encode(updatedUser.getPassword()));
        user.setUsername(updatedUser.getUsername());
        userRepository.save(user);
    }

    public String extractUsername(String token) {
        return jwtUtil.extractUsername(token);
    }
}