package com.shoppingzone.user.service;

import com.shoppingzone.user.model.User;
import com.shoppingzone.user.repository.UserRepository;
import com.shoppingzone.user.security.JwtUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class AuthService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private JwtUtil jwtUtil;

    private final BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

    public String registerUser(User user) {
        user.setPassword(passwordEncoder.encode(user.getPassword()));
        if (user.getRole() == null || user.getRole().equalsIgnoreCase("user")) {
            user.setRole("USER");
        } else {
            user.setRole("ADMIN");
        }
        userRepository.save(user);
        return "User registered successfully!";
    }

    public String loginUser(String username, String password) {
        Optional<User> userOptional = userRepository.findByUsername(username);

        if (userOptional.isPresent()) {
            User user = userOptional.get();
            if (passwordEncoder.matches(password, user.getPassword())) {
                return jwtUtil.generateToken(username, user.getRole());
            }
        }
        throw new RuntimeException("Invalid credentials");
    }

    public boolean validateUserAccess(String token, String username, String requiredRole) {
        try {
            return jwtUtil.validateToken(token, username, requiredRole);
        } catch (SecurityException e) {
            throw new RuntimeException("Forbidden: Insufficient role permissions");
        }
    }
    
    public User getUserByUsername(String username) {
        return userRepository.findByUsername(username).orElse(null);
    }
}