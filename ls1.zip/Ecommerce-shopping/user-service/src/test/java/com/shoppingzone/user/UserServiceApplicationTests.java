//package com.shoppingzone.user;
//
//import com.shoppingzone.user.model.User;
//import com.shoppingzone.user.repository.UserRepository;
//import com.shoppingzone.user.security.JwtUtil;
//import com.shoppingzone.user.service.AuthService;
//import com.shoppingzone.user.service.UserService;
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//import org.junit.jupiter.api.extension.ExtendWith;
//import org.mockito.*;
//import org.mockito.junit.jupiter.MockitoExtension;
//import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
//
//import java.util.List;
//import java.util.Optional;
//
//import static org.junit.jupiter.api.Assertions.*;
//import static org.mockito.Mockito.*;
//
//@ExtendWith(MockitoExtension.class)
//class UserServiceApplicationTests {
//
//    @Mock
//    private UserRepository userRepository;
//    @Mock
//    private JwtUtil jwtUtil;
//
//    @InjectMocks
//    private AuthService authService;
//
//    @InjectMocks
//    private UserService userService;
//
//    private BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
//
//    @BeforeEach
//    void setUp() {
//        MockitoAnnotations.openMocks(this);
//    }
//
//    @Test
//    void registerUser_shouldEncodePasswordAndSaveUserWithUserRole() {
//        User user = new User(null, "testuser", "password", "user", "address1");
//        when(userRepository.save(any(User.class))).thenAnswer(invocation -> {
//            User u = invocation.getArgument(0);
//            u.setId(1L);
//            return u;
//        });
//
//        String result = authService.registerUser(user);
//
//        assertEquals("User registered successfully!", result);
//        ArgumentCaptor<User> captor = ArgumentCaptor.forClass(User.class);
//        verify(userRepository).save(captor.capture());
//        User captured = captor.getValue();
//        assertTrue(passwordEncoder.matches("password", captured.getPassword()));
//        assertEquals("USER", captured.getRole());
//    }
//
//    @Test
//    void registerUser_shouldSetAdminRoleIfGiven() {
//        User user = new User(null, "admin", "adminpass", "ADMIN", "address2");
//        when(userRepository.save(any(User.class))).thenAnswer(invocation -> {
//            User u = invocation.getArgument(0);
//            u.setId(2L);
//            return u;
//        });
//
//        String result = authService.registerUser(user);
//
//        assertEquals("User registered successfully!", result);
//        ArgumentCaptor<User> captor = ArgumentCaptor.forClass(User.class);
//        verify(userRepository).save(captor.capture());
//        User captured = captor.getValue();
//        assertEquals("ADMIN", captured.getRole());
//    }
//
//    @Test
//    void loginUser_shouldReturnTokenForValidCredentials() {
//        String rawPassword = "password";
//        String encodedPassword = passwordEncoder.encode(rawPassword);
//        User user = new User(1L, "testuser", encodedPassword, "USER", "address1");
//        when(userRepository.findByUsername("testuser")).thenReturn(Optional.of(user));
//        when(jwtUtil.generateToken("testuser", "USER")).thenReturn("token");
//
//        String token = authService.loginUser("testuser", rawPassword);
//
//        assertEquals("token", token);
//    }
//
//    @Test
//    void loginUser_shouldThrowExceptionForInvalidUsername() {
//        when(userRepository.findByUsername("nouser")).thenReturn(Optional.empty());
//
//        assertThrows(RuntimeException.class, () -> authService.loginUser("nouser", "password"));
//    }
//
//    @Test
//    void loginUser_shouldThrowExceptionForInvalidPassword() {
//        String encodedPassword = passwordEncoder.encode("password");
//        User user = new User(1L, "testuser", encodedPassword, "USER", "address1");
//        when(userRepository.findByUsername("testuser")).thenReturn(Optional.of(user));
//
//        assertThrows(RuntimeException.class, () -> authService.loginUser("testuser", "wrongpassword"));
//    }
//
//    @Test
//    void getAllUsers_shouldReturnUserList() {
//        List<User> users = List.of(new User(1L, "user1", "pass", "USER", "address1"));
//        when(userRepository.findAll()).thenReturn(users);
//
//        List<User> result = userService.getAllUsers();
//
//        assertEquals(1, result.size());
//        assertEquals("user1", result.get(0).getUsername());
//    }
//
//    @Test
//    void deleteUser_shouldCallRepositoryDelete() {
//        doNothing().when(userRepository).deleteById(1L);
//
//        userService.deleteUser(1L);
//
//        verify(userRepository).deleteById(1L);
//    }
//
//    @Test
//    void updateUser_shouldUpdateOwnDetails() {
//        User existing = new User(1L, "user1", passwordEncoder.encode("oldpass"), "USER", "address1");
//        User updated = new User(null, "user1", "newpass", "USER", "address2");
//        when(userRepository.findById(1L)).thenReturn(Optional.of(existing));
//        when(userRepository.save(any(User.class))).thenReturn(existing);
//
//        userService.updateUser(1L, "user1", updated);
//
//        ArgumentCaptor<User> captor = ArgumentCaptor.forClass(User.class);
//        verify(userRepository).save(captor.capture());
//        User saved = captor.getValue();
//        assertTrue(passwordEncoder.matches("newpass", saved.getPassword()));
//        assertEquals("user1", saved.getUsername());
//        assertEquals("address2", saved.getAddress());
//    }
//
//    @Test
//    void updateUser_shouldThrowIfUsernameMismatch() {
//        User existing = new User(1L, "user1", passwordEncoder.encode("oldpass"), "USER", "address1");
//        User updated = new User(null, "user1", "newpass", "USER", "address2");
//        when(userRepository.findById(1L)).thenReturn(Optional.of(existing));
//
//        assertThrows(RuntimeException.class, () -> userService.updateUser(1L, "otheruser", updated));
//    }
//}