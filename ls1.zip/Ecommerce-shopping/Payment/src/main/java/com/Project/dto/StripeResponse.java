package com.Project.dto;

public class StripeResponse {

    private String status;
    private String message;
    private String sessionId;
    private String sessionUrl;

    // Private constructor to enforce usage of Builder
    private StripeResponse(Builder builder) {
        this.status = builder.status;
        this.message = builder.message;
        this.sessionId = builder.sessionId;
        this.sessionUrl = builder.sessionUrl;
    }

    // Getters
    public String getStatus() { return status; }
    public String getMessage() { return message; }
    public String getSessionId() { return sessionId; }
    public String getSessionUrl() { return sessionUrl; }

    // Builder Class
    public static class Builder {
        private String status;
        private String message;
        private String sessionId;
        private String sessionUrl;

        public Builder setStatus(String status) {
            this.status = status;
            return this;
        }

        public Builder setMessage(String message) {
            this.message = message;
            return this;
        }

        public Builder setSessionId(String sessionId) {
            this.sessionId = sessionId;
            return this;
        }

        public Builder setSessionUrl(String sessionUrl) {
            this.sessionUrl = sessionUrl;
            return this;
        }

        public StripeResponse build() {
            return new StripeResponse(this);
        }
    }
}