package com.Project.dto;

import org.springframework.stereotype.Service;

@Service
public class BookingRequest {
	 private Long amount;
	 private Long noOfTickets;
	 private String name;
	 private String currency;
	public Long getAmount() {
		return amount;
	}
	public void setAmount(Long amount) {
		this.amount = amount;
	}
	public Long getNoOfTickets() {
		return noOfTickets;
	}
	public void setNoOfTickets(Long noOfTickets) {
		this.noOfTickets = noOfTickets;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public BookingRequest(Long amount, Long noOfTickets, String name, String currency) {
		super();
		this.amount = amount;
		this.noOfTickets = noOfTickets;
		this.name = name;
		this.currency = currency;
	}
	public BookingRequest() {
		super();
	}
	 
	 
}
