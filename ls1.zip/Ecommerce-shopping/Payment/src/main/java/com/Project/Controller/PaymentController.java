package com.Project.Controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/payment")
public class PaymentController {

    @PostMapping("/pay")
    public ResponseEntity<String> pay(@RequestParam Long userId, @RequestParam double amount) {
        // Here you can call your Stripe logic or just return success for now
        // For demo, just return success
        return ResponseEntity.ok("Payment successful");
    }
}