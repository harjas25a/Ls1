package com.shoppingzone.gateway.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.gateway.route.RouteLocator;
import org.springframework.cloud.gateway.route.builder.RouteLocatorBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.shoppingzone.gateway.filter.JwtAuthenticationFilter;

@Configuration
public class GatewayConfig {
    @Autowired
    private JwtAuthenticationFilter jwtAuthenticationFilter;

    @Bean
    public RouteLocator customRouteLoader(RouteLocatorBuilder builder) {
        return builder.routes()
            // Public auth endpoints (register, login)
            .route("user-auth", r -> r
                .path("/auth/**")
                .uri("lb://USER-SERVICE"))

            // Get all users and delete user - ADMIN only
            .route("user-get-delete", r -> r
                .path("/users")
                .or().path("/users/{id}")
                .and().method("GET", "DELETE")
                .filters(f -> f.filter(jwtAuthenticationFilter.apply(new JwtAuthenticationFilter.Config("ADMIN"))))
                .uri("lb://USER-SERVICE"))

            // Update user - USER only (backend must check user identity)
            .route("user-update", r -> r
                .path("/users/{id}")
                .and().method("PUT")
                .filters(f -> f.filter(jwtAuthenticationFilter.apply(new JwtAuthenticationFilter.Config("USER"))))
                .uri("lb://USER-SERVICE"))

            // Product endpoints (public)
            .route("product-service", r -> r
                .path("/products/**")
                .uri("lb://PRODUCT-SERVICE"))

            // Admin endpoints for products (ADMIN only)
            .route("admin-service", r -> r
                .path("/admin/**")
                .filters(f -> f.filter(jwtAuthenticationFilter.apply(new JwtAuthenticationFilter.Config("ADMIN"))))
                .uri("lb://PRODUCT-SERVICE"))

            // Order endpoints (USER only)
            .route("order-service", r -> r
                .path("/orders/**")
                .filters(f -> f.filter(jwtAuthenticationFilter.apply(new JwtAuthenticationFilter.Config("USER"))))
                .uri("lb://ORDER-SERVICE"))

            .route("cart-user", r -> r
                    .path("/cart/**")
                    .filters(f -> f.filter(jwtAuthenticationFilter.apply(new JwtAuthenticationFilter.Config("USER"))))
                    .uri("http://localhost:8084/")) // or "lb://CART-SERVICE" if using Eureka


            .build();
    }
}