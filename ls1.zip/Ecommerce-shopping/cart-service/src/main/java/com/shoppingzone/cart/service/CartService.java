package com.shoppingzone.cart.service;

import com.shoppingzone.cart.model.Cart;
import com.shoppingzone.cart.model.CartItem;
import com.shoppingzone.cart.repository.CartRepository;
import com.shoppingzone.cart.client.ProductClient;
import com.shoppingzone.cart.dto.ProductDTO;
import com.shoppingzone.cart.dto.CartDTO;
import com.shoppingzone.cart.dto.CartItemDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class CartService {
    @Autowired
    private CartRepository cartRepository;

    @Autowired
    private ProductClient productClient;

    public Cart getCartByUserId(Long userId) {
        Optional<Cart> optionalCart = cartRepository.findByUserId(userId);
        if (optionalCart.isPresent()) {
            return optionalCart.get();
        } else {
            Cart cart = new Cart();
            cart.setUserId(userId);
            return cartRepository.save(cart);
        }
    }

    public Cart addItemToCart(Long userId, Long productId, int quantity) {
        // Validate product exists and is in stock
        ProductDTO product = productClient.getProductById(productId);
        if (product == null || product.getStock() < quantity) {
            throw new RuntimeException("Product not available or insufficient stock");
        }

        Cart cart = getCartByUserId(userId);
        CartItem existing = null;
        for (CartItem item : cart.getItems()) {
            if (item.getProductId().equals(productId)) {
                existing = item;
                break;
            }
        }
        if (existing != null) {
            existing.setQuantity(existing.getQuantity() + quantity);
        } else {
            CartItem item = new CartItem();
            item.setProductId(productId);
            item.setQuantity(quantity);
            item.setCart(cart);
            cart.getItems().add(item);
        }
        return cartRepository.save(cart);
    }

    public Cart removeItemFromCart(Long userId, Long productId) {
        Cart cart = getCartByUserId(userId);
        cart.getItems().removeIf(item -> item.getProductId().equals(productId));
        return cartRepository.save(cart);
    }

    public void clearCart(Long userId) {
        Cart cart = getCartByUserId(userId);
        cart.getItems().clear();
        cartRepository.save(cart);
    }

    public CartDTO toDTO(Cart cart) {
        CartDTO dto = new CartDTO();
        dto.setId(cart.getId());
        dto.setUserId(cart.getUserId());
        dto.setItems(
            cart.getItems().stream()
                .map(item -> new CartItemDTO(item.getId(), item.getProductId(), item.getQuantity()))
                .collect(Collectors.toList())
        );
        return dto;
    }
}