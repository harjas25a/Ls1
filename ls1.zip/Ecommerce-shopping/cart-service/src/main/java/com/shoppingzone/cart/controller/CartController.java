package com.shoppingzone.cart.controller;

import com.shoppingzone.cart.dto.CartDTO;
import com.shoppingzone.cart.service.CartService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/cart")
public class CartController {
    @Autowired
    private CartService cartService;

    @GetMapping("/{userId}")
    public ResponseEntity<CartDTO> getCart(@PathVariable Long userId) {
        return ResponseEntity.ok(cartService.toDTO(cartService.getCartByUserId(userId)));
    }

    @PostMapping("/{userId}/add")
    public ResponseEntity<CartDTO> addItem(@PathVariable Long userId, @RequestParam Long productId, @RequestParam int quantity) {
        return ResponseEntity.ok(cartService.toDTO(cartService.addItemToCart(userId, productId, quantity)));
    }

    @DeleteMapping("/{userId}/remove")
    public ResponseEntity<CartDTO> removeItem(@PathVariable Long userId, @RequestParam Long productId) {
        return ResponseEntity.ok(cartService.toDTO(cartService.removeItemFromCart(userId, productId)));
    }

    @DeleteMapping("/{userId}/clear")
    public ResponseEntity<Void> clearCart(@PathVariable Long userId) {
        cartService.clearCart(userId);
        return ResponseEntity.ok().build();
    }
}