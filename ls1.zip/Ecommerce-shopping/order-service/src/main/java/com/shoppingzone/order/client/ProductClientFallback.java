package com.shoppingzone.order.client;

import com.shoppingzone.order.dto.ProductDTO;
import org.springframework.stereotype.Component;

@Component
public class ProductClientFallback implements ProductClient {
    @Override
    public ProductDTO getProductById(Long id) {
        // Return null or a default ProductDTO
        return null;
    }

    @Override
    public String decreaseStock(Long id, int quantity) {
        return "Service unavailable";
    }

    @Override
    public String increaseStock(Long id, int quantity) {
        return "Service unavailable";
    }
}