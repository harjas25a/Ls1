package com.shoppingzone.order.service;

import com.shoppingzone.order.client.CartClient;
import com.shoppingzone.order.client.PaymentClient;
import com.shoppingzone.order.client.ProductClient;
import com.shoppingzone.order.dto.CartDTO;
import com.shoppingzone.order.dto.CartItemDTO;
import com.shoppingzone.order.dto.OrderRequest;
import com.shoppingzone.order.dto.ProductDTO;
import com.shoppingzone.order.model.Order;
import com.shoppingzone.order.repository.OrderRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class OrderService {
    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private ProductClient productClient;

    @Autowired
    private CartClient cartClient;

    @Autowired
    private PaymentClient paymentClient;

    public List<Order> placeOrderFromCart(Long userId) {
        CartDTO cart = cartClient.getCartByUserId(userId);
        if (cart == null || cart.getItems() == null || cart.getItems().isEmpty()) {
            throw new RuntimeException("Cart is empty");
        }

        double totalAmount = 0;
        List<Order> orders = new ArrayList<>();
        for (CartItemDTO item : cart.getItems()) {
            ProductDTO product = productClient.getProductById(item.getProductId());
            if (product == null || product.getStock() < item.getQuantity()) {
                throw new RuntimeException("Product not available or insufficient stock for productId: " + item.getProductId());
            }
            String stockResponse = productClient.decreaseStock(product.getId(), item.getQuantity());
            if (!"Stock decreased".equals(stockResponse)) {
                throw new RuntimeException("Could not decrease stock for productId: " + item.getProductId());
            }
            Order order = new Order();
            order.setUserId(userId);
            order.setProductId(product.getId());
            order.setQuantity(item.getQuantity());
            order.setTotalPrice(product.getPrice() * item.getQuantity());
            totalAmount += order.getTotalPrice();
            orders.add(orderRepository.save(order));
        }

//        // Call payment service
//        String paymentResult = paymentClient.makePayment(userId, totalAmount);
//        if (!"Payment successful".equalsIgnoreCase(paymentResult)) {
//            throw new RuntimeException("Payment failed: " + paymentResult);
//        }
        
        cartClient.clearCart(userId);

        return orders;
    }

    public Order placeOrder(OrderRequest orderRequest) {
        ProductDTO product = productClient.getProductById(orderRequest.getProductId());
        if (product == null || product.getStock() < orderRequest.getQuantity()) {
            return null;
        }

        String stockResponse = productClient.decreaseStock(product.getId(), orderRequest.getQuantity());
        if (!"Stock decreased".equals(stockResponse)) {
            return null;
        }

        Order order = new Order();
        order.setUserId(orderRequest.getUserId());
        order.setProductId(product.getId());
        order.setQuantity(orderRequest.getQuantity());
        order.setTotalPrice(product.getPrice() * orderRequest.getQuantity());

        return orderRepository.save(order);
    }

    public List<Order> getOrdersByUserId(Long userId) {
        return orderRepository.findByUserId(userId);
    }

    public String cancelOrder(Long orderId) {
        Order order = orderRepository.findById(orderId).orElse(null);
        if (order != null) {
            productClient.increaseStock(order.getProductId(), order.getQuantity());
            orderRepository.deleteById(orderId);
            return "Order canceled successfully!";
        }
        return "Order not found!";
    }
}