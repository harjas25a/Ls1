package com.shoppingzone.order.controller;

import com.shoppingzone.order.dto.OrderRequest;
import com.shoppingzone.order.model.Order;
import com.shoppingzone.order.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/orders")
public class OrderController {
    @Autowired
    private OrderService orderService;

    @PostMapping("/add")
    public ResponseEntity<Order> placeOrder(@RequestBody @Valid OrderRequest orderRequest) {
        Order order = orderService.placeOrder(orderRequest);
        if (order == null) {
            return ResponseEntity.badRequest().build();
        }
        return ResponseEntity.ok(order);
    }

    @PostMapping("/placeFromCart/{userId}")
    public ResponseEntity<List<Order>> placeOrderFromCart(@PathVariable Long userId) {
        List<Order> orders = orderService.placeOrderFromCart(userId);
        return ResponseEntity.ok(orders);
    }

    @GetMapping("/user/{userId}")
    public ResponseEntity<List<Order>> getOrdersByUserId(@PathVariable Long userId) {
        List<Order> orders = orderService.getOrdersByUserId(userId);
        return ResponseEntity.ok(orders);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> cancelOrder(@PathVariable Long id) {
        String result = orderService.cancelOrder(id);
        return ResponseEntity.ok(result);
    }
}